// lib/utils/constants.dart

class ApiConstants {
  static const String baseUrl = 'https://reqres.in/api/';
  static const String apiKey = 'reqres-free-v1';
}
